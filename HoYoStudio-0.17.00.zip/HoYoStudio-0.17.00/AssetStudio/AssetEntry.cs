﻿namespace AssetStudio
{
    public class AssetEntry
    {
        public string Name;
        public string Container;
        public string SourcePath;
        public long PathID;
        public ClassIDType Type;
    }
}
