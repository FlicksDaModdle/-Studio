namespace AssetStudio
{
	internal enum MetaType
	{
		YAML,
		TAG,
	}
}
