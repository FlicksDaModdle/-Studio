﻿namespace Texture2DDecoder
{
    internal static class T2DDll
    {

        internal const string DllName = "Texture2DDecoderNative";

    }
}
