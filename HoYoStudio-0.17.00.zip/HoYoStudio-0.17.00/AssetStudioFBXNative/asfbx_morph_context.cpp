#include "asfbx_morph_context.h"

AsFbxMorphContext::AsFbxMorphContext()
{
	pMesh = nullptr;
	lBlendShape = nullptr;
	lBlendShapeChannel = nullptr;
	lShape = nullptr;
}
